#include "stdio.h"
#include "sys.h"
#include "string.h"
#include "cpm.h"
#include "math.h"
#include "stdlib.h"

unsigned char *ScrBuf = (unsigned char*)0xf800;
unsigned char *CharSet = (unsigned char*)0xf000;
void cls(char c)
{ 
//	memset(ScrBuf, c, 80*24);
	asm("di");
	asm("ld hl,0");
	asm("ld d,e");
	asm("add hl,sp");
	asm("ld sp,0ff80h");
	asm("ld b, 96");
asm("cloop:");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("djnz cloop");
	asm("ld sp, hl");
}

void pc(char c){ bdos(2, c); }

void ps(char *c)
{
	int l = strlen(c);
	c[l] = '$';
	bdos(9, c);
	c[l] = 0;
}

void rpi(int i, char first, char radix)
{
	if(i<0) { pc('-'), i = -i; }
	if(i) rpi(i / radix, 0, radix); 
	if(i || first) 
	{
		radix = i%radix;
		bdos(2, radix + (radix>9 ? '7' : '0'));
	}
}

void pi(int i, char radix){ rpi(i, 1, radix); }


void pf(float f)
{
	if(f<0) pc('-');
	pi((int)fabs(f), 10);
	pc('.');
	pi((int)fabs(((f-(int)f)*10000)), 10);
}

int pcxy(char c, unsigned char x, unsigned char y){ ScrBuf[x+(y<<6)+(y<<4)] = c; }

const unsigned char ch[8] = {0xff, 0x81, 0xbd, 0xa5,0xa5, 0xbd, 0x81, 0xff}; 

void syncline(int line)
{
asm("rep:");	
	asm("ei");
	asm("halt");
	asm("in a,(0)");
	asm("cp e");
	asm("jr nz, rep");
	asm("in a, (1)");
	asm("and 3");
	asm("cp d");
	asm("jr nz, rep");
	asm("di");
}

#define N 250

void evol(void *p)
{
	asm("ld l,e");
	asm("ld h,d");
	asm("ld bc,500");
	asm("add hl,bc");
	asm("ld bc,4fe6h");
	asm("exx");
	asm("ld bc, 0fa00h");
	asm("ld d, 0f8h");
asm("loop:");
	asm("exx");
	asm("ld a,(de)");
	asm("add a,(hl)");
	asm("ld (de),a");
	asm("call z,adj");
	asm("cp b");
	asm("call z, adj");
	asm("inc hl");
	asm("inc de");
	
	asm("exx");
	asm("ld e,a");
	asm("exx");	

	asm("ld a,(de)");
	asm("add a,(hl)");
	asm("ld (de),a");
	asm("call z,adj");
	asm("cp c");
	asm("call z,adj");
	asm("inc de");
	asm("inc hl");

	asm("exx");
	asm("ld l,a");
	asm("ld h,c");
	asm("add hl,hl");
	asm("add hl,hl");
	asm("add hl,hl");
	asm("add hl,de");
	asm("ld a,b");
	asm("and 63");
	asm("add a,40");
	asm("ld (hl),a");
	asm("djnz loop");
	asm("ret");
asm("adj:");
	asm("xor a");
	asm("sub (hl)");
	asm("ld	(hl),a");
	asm("ld	a,(de)");
	asm("ret");
}

int func()
{
	unsigned char i;
	static unsigned char v[N+N][2];

	for(i=0; i<N; i++)
	{
		v[i][0] = 1+(rand() & 63);
		v[i][1] = (1+(rand() & 15))*10;
		v[i+N][0] = rand() & 1 ? 1 : -1;
		v[i+N][1] = rand() & 1 ? 10 : -10;
	}
	
	do 
	{
		outp(1, 0);
		syncline(20);
		outp(1, 7);
		cls(0);
		evol((void*)v); 
	}
	while(1);
}

void main()
{
	*(unsigned char*)0x81 = 0xc9;
	asm("ld sp, 0000h");

	func();	
	
	asm("rst 0");
}

