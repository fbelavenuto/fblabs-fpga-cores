#include "stdio.h"
#include "sys.h"
#include "string.h"
void exit(char);

const char *ScrBuf = (char*)0xf800;

char toC(char c)
{
	c = c & 15;
	if(c>9) c+=7;
	return c + '0';
}

void cls(){ memset(ScrBuf, ' ', 80*24); }

void main()
{
	unsigned char i, j, *p=ScrBuf;
	cls();
	for(i=0, j=0; i<255; i++)
	{
		*p++ = toC(*(char*)i>>4);
		*p++ = toC(*(char*)i);
		if(!(++j&15)) p += 80 - 47;
		else *p++ = ' ';
	}
	exit(0);
}

void exit(char halt)
{
	*(unsigned char*)0x81 = 0xc9;
	if(halt) asm("halt");
}
