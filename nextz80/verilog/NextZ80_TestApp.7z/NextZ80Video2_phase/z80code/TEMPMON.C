#include "stdio.h"
#include "sys.h"
#include "string.h"
#include "cpm.h"
#include "math.h"
#include "stdlib.h"

unsigned char *ScrBuf = (unsigned char*)0xf800;
unsigned char *CharSet = (unsigned char*)0xf000;
void cls(char c)
{ 
//	memset(ScrBuf, c, 80*24);
	asm("di");
	asm("ld hl,0");
	asm("ld d,e");
	asm("add hl,sp");
	asm("ld sp,7f80h");
	asm("ld b, 96");
asm("cloop:");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("push de");
	asm("djnz cloop");
	asm("ld sp, hl");
}

void pc(char c){ bdos(2, c); }

void ps(char *c)
{
	int l = strlen(c);
	c[l] = '$';
	bdos(9, c);
	c[l] = 0;
}

void rpi(int i, char num, char radix)
{
	if(i<0) { pc('-'), i = -i; }
	if(i || num) 
	{
		rpi(i / radix, num-!!num, radix); 
		radix = i%radix;
		pc(radix + (radix>9 ? '7' : '0'));
	}
}

void pi(int i, char radix, char num){ rpi(i, num, radix); } // num=min number of digits

void pf(float f)
{
	if(f<0) pc('-');
	pi((int)fabs(f), 10,1);
	pc('.');
	pi((int)fabs(((f-(int)f)*10000)), 10, 4);
}

int pcxy(char c, unsigned char x, unsigned char y){ ScrBuf[x+(y<<6)+(y<<4)] = c; }

const unsigned char ch[8] = {0xff, 0x81, 0xbd, 0xa5,0xa5, 0xbd, 0x81, 0xff}; 

void syncline(int line)
{
asm("rep:");	
	asm("ei");
	asm("halt");
	asm("in a,(0)");
	asm("cp e");
	asm("jr nz, rep");
	asm("in a, (1)");
	asm("and 3");
	asm("cp d");
	asm("jr nz, rep");
	asm("di");
}

unsigned char i2csend(int val)
{
// val(DE) = {4'b0000, code[3:0], data[7:0]} - returns 0 if ok
	asm("push bc");
        asm("ld a, e");
        asm("ld c, 40h");
	asm("ld b,d");
        asm("out (c), a");
asm("i2cs1:");
        asm("in a, (1)");
        asm("bit 5, a");
        asm("jr z, i2cs1");
        asm("ld b, 0");
        asm("out (c), a");
asm("i2cs2:");
        asm("in a, (1)");
        asm("bit 5, a");
        asm("jr nz, i2cs2");
        asm("and 40h");
	asm("ld l,a");
	asm("pop bc");
}


int func()	// returns 1 on error
{
        i2csend(0x696);	// write+start at 4bh, write
        i2csend(0x400);	// write reg index
        i2csend(0x697);	// write+start at 4bh, read
        i2csend(0x800);	// read+ack
        asm("in a, (2)");	// read high temp byte
        asm("ld h,a");
 	i2csend(0xd00); 	// read+nack+stop
	asm("in a,(2)");
	asm("ld l,a");
	
}

void main()
{
	long i;
	*(unsigned char*)0x81 = 0xc9;
	asm("ld sp, 0");

again:
	pf(func() * 0.0078125f);
	ps(" C\n");
	for(i=0; i<1600000l; i++);	// delay
	goto again;	
	
	asm("rst 0");
}

